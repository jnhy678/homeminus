package com.homeminus;

import com.homeminus.controller.MainController;
import com.homeminus.dto.ElectProduct;
import com.homeminus.dto.Product;

public class HomeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//하는일 없음. 컨트롤러 호출만 실행.
		MainController mc = new MainController();
		mc.controll();
	}

}
